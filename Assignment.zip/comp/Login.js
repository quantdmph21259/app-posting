import { StyleSheet, Text, View, TextInput, Pressable } from 'react-native'
import React from 'react'
import BouncyCheckbox from "react-native-bouncy-checkbox";
const Login = (props) => {
    return (
        <View style={styles.container}>
            <Text style={styles.text}>Hello</Text>
            <Text style={styles.welcom} >Chào mừng bạn đến với ứng dụng</Text>
            <Text style = {styles.userName}>UserName</Text>
            <TextInput style = {styles.textInput} />
            <Text style = {styles.userName}>PassWord</Text>
            <TextInput style = {styles.textInput} />
            <View style={[styles.viewRemember, {justifyContent:'space-between'}]}>
            <View style = {styles.viewRemember}>
            <BouncyCheckbox fillColor='blue' style = {{marginTop:22,}}/>
            <Text style = {{marginTop:22,}}>Remember me</Text>
            </View>
            <Text style = {{marginTop:22,marginEnd:15}}>Forgot the password ?</Text>
            </View>
            <Pressable style = {styles.buttonLogin} onPress={()=>props.navigation.navigate('List')}>
                <Text style = {styles.textButton}>Login</Text>
            </Pressable>
            <Text style ={{textAlign:'center',marginTop:40}}>Don't have an Account ?</Text>
            <Text style = {{textAlign:'center',fontSize:18,color:"#D9ACF5",marginTop:6}}>REGISTER</Text>
        </View>
    )
}

export default Login

const styles = StyleSheet.create({
    container: {
        flex: 1,//full màn hình
        backgroundColor: "#6096B4",
        // marginStart: 10,
        // marginEnd: 10,
        flexDirection: 'column',
    },
    text: {
        fontSize: 44,
        fontWeight: "bold",
        color: "#B5F1CC",
        margin: 50,
        textAlign: 'center',
    },
    welcom: {
        textAlign:'center',
        fontSize: 22,
        marginTop: 8,
        color: "#EEE9DA",
        marginBottom:20,

    }, 
    userName: {
        marginLeft:20,
        fontSize:18,
    },
    textInput:{
        width:333,
       alignSelf: 'center',//căn giữa
        height:48,
        borderRadius:10,
        borderWidth:1,
        marginTop:8,  
    },
    viewRemember:{
        flexDirection:'row',
        marginLeft:12,
    }, 
    buttonLogin: { 
        borderRadius:14,
        margin:23,
        backgroundColor:"#85CDFD",
        width:122,
        height:44,
        alignSelf: 'center',
       
    },
    textButton: {
        color:"#F1DBBF",
        fontSize:22,
        fontWeight:"bold",
        textAlign:'center',
        margin:2
    },
})