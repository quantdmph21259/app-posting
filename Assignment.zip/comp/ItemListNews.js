import { StyleSheet, Text, View,Image } from 'react-native'
import React from 'react'

const ItemListNews = (props) => {
    const {data} = props;
  return (
    <View style = {styles.container2}>
<Image style = {styles.image} source={{uri: data.image}}/>
<View style = {styles.content}>
  <Text style={styles.textTitle}>{data.title}</Text>
  <Text>{data.content}</Text>
</View>
</View>
  )
}

export default ItemListNews

const styles = StyleSheet.create({
    container2:{
        flexDirection:'row'
    },
    image:{
      width:96,
      height:96,
      borderRadius:10,
      margin:4
    },
    textTitle:{
      fontSize:20,
    },
    content:{
      marginStart: 4,
    }
})