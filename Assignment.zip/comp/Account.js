import { Button, StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Account = () => {
  return (
    <View style={styles.container} >
        <Text style={{fontSize:22,color:'#913175'}}>Posts are tracked here</Text>
      
    </View>
  )
}

export default Account

const styles = StyleSheet.create({})