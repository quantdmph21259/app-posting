import { Button, Pressable, StyleSheet, Text, TextInput, View } from 'react-native'
import React from 'react'

const Post = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.newPost}>Post Hear</Text>
      <TextInput style={styles.Textinput} placeholder="write here............."></TextInput>
      <Pressable style = {styles.button}>
          <Text style = {styles.loginText}>Login</Text>
      </Pressable>
    </View>
  )
}

export default Post

const styles = StyleSheet.create({
    container:{
        marginTop:20,
        flex:1,
        flexDirection:'column',
    },
    newPost:{
        fontWeight:'bold',
        fontSize:30,
        color:"#AA5656",
        textAlign:'center'
       
    },
    Textinput:{
        height:100,
        borderRadius:10,
        borderWidth:1,
        borderColor:"blue",
        marginTop:20
    },
    button:{
      borderRadius:14,
        margin:23,
        backgroundColor:"#85CDFD",
        width:122,
        height:44,
        alignSelf: 'center',
    },
    loginText:{
      textAlign:"center",
      margin: 6,
      fontSize:16,

    }

})