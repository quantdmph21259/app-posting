import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Login from './comp/Login';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import List from './comp/List';
import Post from './comp/Post';
import Account from './comp/Account';

const StackDemo = createNativeStackNavigator();
export default function App() {
  return (
    <NavigationContainer>

      <StackDemo.Navigator initialRouteName='Login'>
        <StackDemo.Screen name='Login' component={Login} options={{title:'Login'}} />
        <StackDemo.Screen name='List' component={List} options={{title:'News'}} />
        <StackDemo.Screen name='Post' component={Post} options={{title:'Post'}} />
        <StackDemo.Screen name='Account' component={Account} options={{title:'Account'}} />
      </StackDemo.Navigator>

    </NavigationContainer>
  );
}

